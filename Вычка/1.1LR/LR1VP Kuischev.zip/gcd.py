a = int(input('a: '))
b = int(input('b: '))

while(min(a, b)):
    if a > b:
        a %= b
    else:
        b %= a
if a:
    gcd = a
else:
    gcd = b
    
print(gcd)
    