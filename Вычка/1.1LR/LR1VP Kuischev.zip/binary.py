import sys
# calc binary digits for any number
n = int(input('num: '))
base = int(input('base: '))

s = ''
while (n > 0):
    s = s + str(n % base)
    n = n // base
num = s[::-1] #реверсирует строку
print(num) 