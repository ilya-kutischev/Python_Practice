x = 0
n = 1
while 1/n:
    x = x + 1/n
    if x > n:
        break
    else:
        n +=1
        
print(n)