n = int(input('n: '))
y = int(input('y: '))
p = int(input('%: '))#тут указываем в обычных процентах, например 30, а не 1.3
per = int(input('Periods: '))#тут указываем на каких периодах будет зачисляться процент, если каждый месяц, то 12 и тд.
al = int(input('Do you want to see sum of each period? 1-y/0-n: '))
for x in range(y*per):
    n = n * (1+p/100*per)
    if al:
        print('The sum after '+str(x)+' periods = '+str(n))

print('The sum after all periods = '+str(n))
#можно заметить, что при пересчёте сложного процента
#чем больше периодов начисления- тем больше сумма