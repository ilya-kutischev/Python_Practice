import random
stake = int(input('stake: '))
trials = int(input('trials: '))
fl = 1
while fl:
    counter = 0
    s = stake
    maxS = stake
    while s and s < trials:
        counter += 1 #для подсчёта среднего количества итераций
        if s > maxS: #для вычисления максимальных значений
            maxS = s
        if random.randrange(2):
            s += 1
        else:
            s -= 1
        
    if s:
        print('you win!')
    else:
        print('you lose(')
    print('количество итераций: '+str(counter))
    print('максимальное значение: '+str(maxS))
    fl = int(input('wanna continue? 1-y,0-n: '))
#на практике получилось вероятность около 10% увелисить свой выигрыш в 10 раз
#для того чтобы игрок выиграл 10 или проиграл 10 очков в среденем надо около 100 итераций, при этом значение очень сильно колебается.
#при параметрах stack= 10 trails= 20, среднее максимальное колеблется около 18