x = int(input('x: '))

if x < -1:
    answ = -x - 1
elif x < 0:
    answ = x + 1
elif x < 0:
    answ = -x + 1
else:
    answ = x - 1
print(answ)